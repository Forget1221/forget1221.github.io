package com.bay4lly.secretroomsport;

import com.bay4lly.secretroomsport.init.ModBlockEntities;
import com.bay4lly.secretroomsport.init.ModBlocks;
import com.bay4lly.secretroomsport.init.ModCreativeTabs;
import com.bay4lly.secretroomsport.init.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(SecretRoomsPort.MOD_ID)
public class SecretRoomsPort {
    public static final String MOD_ID = "secretroomsport";
    private static final Logger LOGGER = LogUtils.getLogger();

    public SecretRoomsPort() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        // Register blocks, items and block entities
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        
        // Register creative mode tab
        ModCreativeTabs.CREATIVE_TABS.register(modEventBus);
        
        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);
    }
} 