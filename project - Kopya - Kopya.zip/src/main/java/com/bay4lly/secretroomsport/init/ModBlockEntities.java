package com.bay4lly.secretroomsport.init;

import com.bay4lly.secretroomsport.SecretRoomsPort;
import com.bay4lly.secretroomsport.block.MimicBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = 
        DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, SecretRoomsPort.MOD_ID);

    public static final RegistryObject<BlockEntityType<MimicBlockEntity>> MIMIC_BLOCK = 
        BLOCK_ENTITIES.register("mimic_block",
            () -> BlockEntityType.Builder.of(MimicBlockEntity::new, ModBlocks.MIMIC_BLOCK.get())
                .build(null));
} 