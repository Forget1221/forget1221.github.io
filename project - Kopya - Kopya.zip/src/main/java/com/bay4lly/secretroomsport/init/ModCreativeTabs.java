package com.bay4lly.secretroomsport.init;

import com.bay4lly.secretroomsport.SecretRoomsPort;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SecretRoomsPort.MOD_ID);
    
    public static final RegistryObject<CreativeModeTab> SECRET_ROOMS_TAB = CREATIVE_TABS.register("secret_rooms", 
        () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.secretroomsport")) // Tab başlığı
            .icon(() -> new ItemStack(ModItems.MIMIC_BLOCK.get())) // Tab ikonu
            .displayItems((parameters, output) -> {
                // Tab'a eklenecek itemlar
                output.accept(ModItems.MIMIC_BLOCK.get());
                // Sonradan eklenecek diğer itemler buraya eklenebilir
            })
            .build()
    );
} 