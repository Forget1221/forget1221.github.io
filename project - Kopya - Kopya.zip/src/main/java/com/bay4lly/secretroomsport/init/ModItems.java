package com.bay4lly.secretroomsport.init;

import com.bay4lly.secretroomsport.SecretRoomsPort;
import com.bay4lly.secretroomsport.item.MimicItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SecretRoomsPort.MOD_ID);

    public static final RegistryObject<Item> MIMIC_BLOCK = ITEMS.register("mimic_block",
            () -> new MimicItem(new Item.Properties()));
} 