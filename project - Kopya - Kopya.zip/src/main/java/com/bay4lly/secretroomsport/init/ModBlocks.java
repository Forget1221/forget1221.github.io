package com.bay4lly.secretroomsport.init;

import com.bay4lly.secretroomsport.SecretRoomsPort;
import com.bay4lly.secretroomsport.block.MimicBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SecretRoomsPort.MOD_ID);

    public static final RegistryObject<Block> MIMIC_BLOCK = BLOCKS.register("mimic_block",
            () -> new MimicBlock(BlockBehaviour.Properties.of()
                    .strength(0.3f)
                    .noOcclusion()
                    .isViewBlocking((state, level, pos) -> false)
            ));
} 