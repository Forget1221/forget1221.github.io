package com.bay4lly.secretroomsport.block;

import com.bay4lly.secretroomsport.init.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class MimicBlockEntity extends BlockEntity {
    private BlockState mimickedState;

    public MimicBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.MIMIC_BLOCK.get(), pos, state);
        this.mimickedState = Blocks.STONE.defaultBlockState(); // Varsayılan olarak taş görünümü
    }

    public BlockState getMimickedState() {
        return mimickedState != null ? mimickedState : Blocks.STONE.defaultBlockState();
    }

    public void setMimickedState(BlockState mimickedState) {
        if (mimickedState == null || mimickedState.isAir()) {
            this.mimickedState = Blocks.STONE.defaultBlockState();
        } else {
            this.mimickedState = mimickedState;
        }
        
        // Değişiklikleri kaydet ve client tarafına bildir
        setChanged();
        
        Level level = getLevel();
        if (level != null && !level.isClientSide) {
            // Client tarafına anında güncelleme gönder
            level.sendBlockUpdated(getBlockPos(), getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        // mimickedState'i kaydet
        tag.put("MimickedState", NbtUtils.writeBlockState(getMimickedState()));
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        try {
            if (tag.contains("MimickedState")) {
                // Forge 1.20.1'de HolderLookup parametresi gerekiyor
                mimickedState = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("MimickedState"));
            } else {
                mimickedState = Blocks.STONE.defaultBlockState();
            }
        } catch (Exception e) {
            // Hata durumunda taş blok kullan
            mimickedState = Blocks.STONE.defaultBlockState();
            System.err.println("Mimic block entity yüklenirken hata: " + e.getMessage());
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
    
    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        // Server'dan gelen paket ile verileri güncelle
        CompoundTag tag = pkt.getTag();
        if (tag != null) {
            load(tag);
        }
    }
    
    // Client tarafında updatePacket'i işleme
    @Override
    public void handleUpdateTag(CompoundTag tag) {
        if (tag != null) {
            load(tag);
        }
    }
} 