package com.bay4lly.secretroomsport.client;

import com.bay4lly.secretroomsport.client.renderer.MimicBlockRenderer;
import com.bay4lly.secretroomsport.init.ModBlockEntities;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

import com.bay4lly.secretroomsport.SecretRoomsPort;

@Mod.EventBusSubscriber(modid = SecretRoomsPort.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            BlockEntityRenderers.register(ModBlockEntities.MIMIC_BLOCK.get(), MimicBlockRenderer::new);
        });
    }
} 