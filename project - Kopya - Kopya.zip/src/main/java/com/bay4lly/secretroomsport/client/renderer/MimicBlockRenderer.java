package com.bay4lly.secretroomsport.client.renderer;

import com.bay4lly.secretroomsport.block.MimicBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.model.data.ModelData;

public class MimicBlockRenderer implements BlockEntityRenderer<MimicBlockEntity> {
    private final BlockRenderDispatcher blockRenderer;

    public MimicBlockRenderer(BlockEntityRendererProvider.Context context) {
        this.blockRenderer = context.getBlockRenderDispatcher();
    }

    @Override
    public void render(MimicBlockEntity blockEntity, float partialTicks, PoseStack poseStack, 
                       MultiBufferSource bufferSource, int combinedLight, int combinedOverlay) {
        // Taklit edilen bloğun durumunu al
        BlockState mimicState = blockEntity.getMimickedState();
        
        if (mimicState == null) {
            return;
        }
        
        // PoseStack'i kaydet
        poseStack.pushPose();
        
        try {
            // Render işlemini gerçekleştir - RenderType belirtmeden direkt render et
            blockRenderer.renderSingleBlock(
                mimicState, 
                poseStack, 
                bufferSource, 
                combinedLight, 
                OverlayTexture.NO_OVERLAY, 
                ModelData.EMPTY, 
                null
            );
        } catch (Exception e) {
            System.err.println("MimicBlock render hatası: " + e.getMessage());
            e.printStackTrace();
        }
        
        // PoseStack'i geri yükle
        poseStack.popPose();
    }
} 