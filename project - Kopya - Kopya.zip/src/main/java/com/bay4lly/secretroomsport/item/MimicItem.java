package com.bay4lly.secretroomsport.item;

import com.bay4lly.secretroomsport.block.MimicBlockEntity;
import com.bay4lly.secretroomsport.init.ModBlocks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class MimicItem extends Item {
    
    public MimicItem(Properties properties) {
        super(properties);
    }
    
    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos clickedPos = context.getClickedPos();
        Direction clickedFace = context.getClickedFace();
        BlockState clickedBlockState = level.getBlockState(clickedPos);
        
        // Tıklanan bloğun, tıklanan yüzün karşı tarafındaki pozisyon (boş olmalı)
        BlockPos placementPos = clickedPos.relative(clickedFace);
        
        if (level.isEmptyBlock(placementPos)) {
            if (!level.isClientSide) {
                // Mimic bloğunu yerleştir
                level.setBlock(placementPos, ModBlocks.MIMIC_BLOCK.get().defaultBlockState(), 3);
                
                // BlockEntity'yi al ve taklit etmek istediğimiz bloğu ayarla
                BlockEntity blockEntity = level.getBlockEntity(placementPos);
                if (blockEntity instanceof MimicBlockEntity mimicEntity) {
                    // Tıklanan bloğun görünümünü kopyala
                    mimicEntity.setMimickedState(clickedBlockState);
                    
                    // Değişiklikleri hemen güncelle
                    level.sendBlockUpdated(placementPos, level.getBlockState(placementPos), 
                                        level.getBlockState(placementPos), 3);
                }
                
                // Oyuncunun elindeki itemi azalt (creative modunda değilse)
                if (!context.getPlayer().getAbilities().instabuild) {
                    context.getItemInHand().shrink(1);
                }
            }
            
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        
        return InteractionResult.FAIL;
    }
} 